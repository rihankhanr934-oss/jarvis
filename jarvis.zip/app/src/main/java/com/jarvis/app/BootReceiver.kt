package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!c.getSharedPreferences("j", Context.MODE_PRIVATE).getBoolean("enabled", false)) return
        if (Build.VERSION.SDK_INT < 34) {
            try { c.startForegroundService(Intent(c, JarvisService::class.java)) } catch (e: Exception) {}
            return
        }
        // Android 14+ boot se mic service shuru karne nahi deta: ek tap wali notification do.
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tap", "Jarvis jagao", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java).putExtra("start", true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            2,
            Notification.Builder(c, "tap")
                .setContentTitle("Jarvis taiyar hai")
                .setContentText("Jagane ke liye ek baar dabao")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }
}
