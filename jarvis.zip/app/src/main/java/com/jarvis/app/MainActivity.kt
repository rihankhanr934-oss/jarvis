package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private val prefs by lazy { getSharedPreferences("j", Context.MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#02070D"))
        }
        fun tv(t: String, size: Float, color: String) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, pad / 2, 0, pad / 2)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setAllCaps(false); setOnClickListener { f() }
        }
        col.addView(tv("J.A.R.V.I.S.", 28f, "#2EE6FF"))
        col.addView(tv("Claude API key (sk-ant-...) yahan daalo:", 14f, "#D8F8FF"))
        val key = EditText(this).apply {
            setText(prefs.getString("key", ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); hint = "sk-ant-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        col.addView(key)
        col.addView(btn("Key save karo") {
            prefs.edit().putString("key", key.text.toString().trim()).apply(); toast("Save ho gaya")
        })
        col.addView(tv("Ek baar ye chaaron karo:", 14f, "#D8F8FF"))
        col.addView(btn("1. Mic, call, contacts, notification ki ijazat") { askPerms() })
        col.addView(btn("2. Doosre apps ke upar dikhane ki ijazat") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("3. Accessibility mein Jarvis chalu karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("4. Battery restriction hatao") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        toggle = btn("") { toggleJarvis() }
        col.addView(toggle)
        status = tv("", 14f, "#6FA6B3")
        col.addView(status)
        setContentView(ScrollView(this).apply { addView(col) })
        refresh()
        if (intent.getBooleanExtra("start", false)) startJarvis()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun askPerms() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    private fun toggleJarvis() {
        if (prefs.getBoolean("enabled", false)) {
            prefs.edit().putBoolean("enabled", false).apply()
            stopService(Intent(this, JarvisService::class.java))
            refresh()
        } else startJarvis()
    }

    private fun startJarvis() {
        if ((prefs.getString("key", "") ?: "").isBlank()) { toast("Pehle API key save karo"); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle step 1 mein mic ki ijazat do"); return
        }
        prefs.edit().putBoolean("enabled", true).apply()
        startForegroundService(Intent(this, JarvisService::class.java))
        refresh()
    }

    private fun refresh() {
        val on = prefs.getBoolean("enabled", false)
        toggle.text = if (on) "Jarvis BAND karo" else "Jarvis CHALU karo"
        status.text = if (on) "Chalu hai. Bolo: \"Jarvis, ...\"" else "Band hai."
    }
}
