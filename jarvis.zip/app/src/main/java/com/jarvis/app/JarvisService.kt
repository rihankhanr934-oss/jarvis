package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val MODEL = "claude-haiku-5-5"
        val WAKE = listOf(
            "jarvis", "जार्विस", "जार्वीस", "जर्विस", "जारविस", "जारवीस",
            "ज़ार्विस", "ज़ारविस", "जरविस", "जार्विश", "जारविश"
        )
        const val SYSTEM = """Tum JARVIS ho, Tony Stark ka AI assistant, aur ab user ke Android phone ke andar chal rahe ho. User ko "sir" bolo. User jis bhasha mein bole (Hindi/Hinglish/English) usi mein jawab do; Hindi mein bole to Devanagari mein likho. Jawab bahut chhota rakho (1-2 vaakya), confident aur thoda witty. Tum phone ko control kar sakte ho. HAMESHA sirf ek JSON object se jawab do, aur kuch nahi: {"say":"bolne wala jawab","actions":[...]}. actions optional hai; sirf baat ho to mat do. Action types: {"type":"open_app","name":"WhatsApp"} ; {"type":"call","to":"naam ya number"} ; {"type":"sms","to":"naam ya number","text":"..."} ; {"type":"whatsapp","to":"naam ya number","text":"..."} ; {"type":"url","url":"https://..."} ; {"type":"youtube","query":"..."} ; {"type":"search","query":"..."} ; {"type":"navigate","query":"jagah"} ; {"type":"alarm","hour":7,"minute":30,"label":"..."} ; {"type":"timer","seconds":300} ; {"type":"torch","on":true} ; {"type":"volume","dir":"up|down|mute"} ya {"type":"volume","level":50} ; {"type":"media","cmd":"play_pause|next|previous"} ; {"type":"settings","page":"wifi|bluetooth|settings"} ; {"type":"global","cmd":"back|home|recents|notifications|quick_settings|screenshot|lock"} ; {"type":"tap","text":"screen par dikhne wala text"} ; {"type":"scroll","dir":"up|down"} ; {"type":"type","text":"..."}. Jo kaam in actions se nahi ho sakta, uske liye saaf bolo ki nahi kar sakta; jhooth mat bolo ki ho gaya."""
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ok = false
    private var running = false
    private var speaking = false
    private var busy = false
    private var awakeUntil = 0L
    private var wl: PowerManager.WakeLock? = null
    private val history = ArrayList<Pair<String, String>>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis chalu hai")
            .setContentText("\"Jarvis\" bolkar jagaiye")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return }
        ok = true
        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:w").also { it.acquire() }
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!ok) return START_NOT_STICKY
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        rec?.destroy(); rec = null
        tts?.shutdown()
        try { wl?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { speaking = false; listen() }
            override fun onError(id: String?) { speaking = false; listen() }
        })
        running = true
        speak("Jarvis online, sir.")
    }

    private fun speak(text: String) {
        if (text.isBlank() || !ttsReady) { speaking = false; listen(); return }
        speaking = true
        main.post { rec?.destroy(); rec = null }
        val hi = text.any { it in '\u0900'..'\u097F' }
        tts?.setLanguage(if (hi) Locale("hi", "IN") else Locale("en", "IN"))
        tts?.setPitch(0.8f)
        tts?.speak(text.replace(Regex("[*_#`]"), ""), TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        main.post {
            if (!running || speaking || busy) return@post
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return@post
            rec?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) {
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return
                    if (rec === r) main.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2000L else 600L)
                }
                override fun onResults(res: Bundle?) {
                    val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    heard(t)
                }
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            })
        }
    }

    private fun heard(t: String) {
        val low = t.lowercase()
        val now = System.currentTimeMillis()
        val has = WAKE.any { low.contains(it) }
        if (!has && now > awakeUntil) { listen(); return }
        var cmd = t
        for (w in WAKE) cmd = cmd.replace(w, "", ignoreCase = true)
        cmd = cmd.trim(' ', ',', '.')
        if (cmd.isBlank()) { awakeUntil = now + 10000; speak("Ji sir?") }
        else { awakeUntil = 0; process(cmd) }
    }

    private fun process(cmd: String) {
        val key = getSharedPreferences("j", Context.MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isBlank()) { speak("Sir, pehle app mein API key daaliye."); return }
        busy = true
        Thread {
            val out = try { ask(key, cmd) } catch (e: Exception) {
                JSONObject().put("say", "Sir, internet ya key mein dikkat hai.")
            }
            main.post { busy = false; act(out) }
        }.start()
    }

    private fun ask(key: String, cmd: String): JSONObject {
        val msgs = JSONArray()
        for ((r, c) in history.takeLast(8)) msgs.put(JSONObject().put("role", r).put("content", c))
        msgs.put(JSONObject().put("role", "user").put("content", cmd))
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale("en", "IN")).format(Date())
        val body = JSONObject().put("model", MODEL).put("max_tokens", 500)
            .put("system", SYSTEM + " Abhi: " + now).put("messages", msgs)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) {
            return JSONObject().put("say", if (code == 401) "Sir, API key galat lagti hai." else "Sir, Claude se error aaya, code $code.")
        }
        val reply = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text").trim()
        val out = try {
            JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
        } catch (e: Exception) { JSONObject().put("say", reply) }
        history.add("user" to cmd); history.add("assistant" to reply)
        return out
    }

    private fun act(o: JSONObject) {
        val a = o.optJSONArray("actions")
        if (a != null) for (i in 0 until a.length()) {
            try { doAction(a.getJSONObject(i)) } catch (e: Exception) {}
        }
        speak(o.optString("say", ""))
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun view(u: String) = Intent(Intent.ACTION_VIEW, Uri.parse(u))
    private fun go(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) {}
    }

    private fun doAction(a: JSONObject) {
        when (a.optString("type")) {
            "open_app" -> openApp(a.optString("name"))
            "call" -> {
                val n = number(a.optString("to"))
                if (n != null) {
                    val granted = checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                    go(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + n)))
                }
            }
            "sms" -> {
                val n = number(a.optString("to"))
                if (n != null) go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + n)).putExtra("sms_body", a.optString("text")))
            }
            "whatsapp" -> {
                var n = number(a.optString("to"))?.filter { it.isDigit() }
                if (n != null) {
                    if (n.length == 10) n = "91" + n
                    go(view("https://wa.me/" + n + "?text=" + enc(a.optString("text"))))
                }
            }
            "url" -> go(view(a.optString("url")))
            "youtube" -> go(view("https://www.youtube.com/results?search_query=" + enc(a.optString("query"))))
            "search" -> go(view("https://www.google.com/search?q=" + enc(a.optString("query"))))
            "navigate" -> go(view("google.navigation:q=" + enc(a.optString("query"))))
            "alarm" -> go(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            "timer" -> go(
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            "torch" -> torch(a.optBoolean("on", true))
            "volume" -> volume(a)
            "media" -> media(a.optString("cmd"))
            "settings" -> go(
                Intent(
                    when (a.optString("page")) {
                        "wifi" -> Settings.ACTION_WIFI_SETTINGS
                        "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                        else -> Settings.ACTION_SETTINGS
                    }
                )
            )
            "global" -> JarvisAccess.inst?.global(a.optString("cmd"))
            "tap" -> JarvisAccess.inst?.tapText(a.optString("text"))
            "scroll" -> JarvisAccess.inst?.scroll(a.optString("dir") == "down")
            "type" -> JarvisAccess.inst?.typeText(a.optString("text"))
        }
    }

    private fun number(to: String): String? {
        if (to.isBlank()) return null
        if (to.count { it.isDigit() } >= 6) return to.filter { it.isDigit() || it == '+' }
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val p = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        contentResolver.query(
            p, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%" + to + "%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun openApp(name: String) {
        val n = name.lowercase().trim()
        if (n.isBlank()) return
        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) } ?: return
        go(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(m.activityInfo.packageName, m.activityInfo.name)
        )
    }

    private fun torch(on: Boolean) {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        for (id in cm.cameraIdList) {
            if (cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                cm.setTorchMode(id, on); return
            }
        }
    }

    private fun volume(a: JSONObject) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        if (a.has("level")) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, a.optInt("level") * max / 100, AudioManager.FLAG_SHOW_UI)
        } else {
            val d = when (a.optString("dir")) {
                "up" -> AudioManager.ADJUST_RAISE
                "down" -> AudioManager.ADJUST_LOWER
                else -> AudioManager.ADJUST_MUTE
            }
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
        }
    }

    private fun media(c: String) {
        val code = when (c) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
